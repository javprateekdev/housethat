import React from "react";
import {
  Box,
  Container,
  Row,
  Column,
  FooterLink,
  Heading,
} from "./FooterStyles";
  
const Footer = () => {
  return (
    <Box>
      <p style={{ color: "#ffffff", 
                   textAlign: "center",
                  
                  }}> 

© Copyright 2022 | HouseThat | All right reserved
      </p>
    
    </Box>
  );
};
export default Footer;